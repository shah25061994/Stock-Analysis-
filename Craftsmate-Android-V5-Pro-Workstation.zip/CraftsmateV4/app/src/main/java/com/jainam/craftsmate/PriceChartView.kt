package com.jainam.craftsmate
import android.content.Context
import android.graphics.*
import android.view.View

class PriceChartView(c:Context):View(c){
    private var prices:List<Double> = emptyList(); private var sup=emptyList<Double>(); private var res=emptyList<Double>()
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
    fun setData(p:List<Double>,s:List<Double>,r:List<Double>){prices=p;sup=s;res=r;invalidate()}
    override fun onDraw(canvas:Canvas){super.onDraw(canvas); if(prices.size<2)return; val pad=24f; val min=prices.takeLast(90).minOrNull()?:0.0; val max=prices.takeLast(90).maxOrNull()?:1.0; val span=max-min
        paint.style=Paint.Style.STROKE; paint.strokeWidth=3f
        val arr=prices.takeLast(90); val path=Path(); arr.forEachIndexed{ i,v->val x=pad+i*(width-2*pad)/(arr.size-1); val y=(height-pad)-((v-min)/span)*(height-2*pad); if(i==0)path.moveTo(x,y)else path.lineTo(x,y)}; canvas.drawPath(path,paint)
        paint.style=Paint.Style.FILL;paint.textSize=12f
        sup.forEach{if(it in min..max){val y=(height-pad)-((it-min)/span)*(height-2*pad);canvas.drawText("S ₹${String.format("%.0f",it)}",pad,y-4,paint)}}
        res.forEach{if(it in min..max){val y=(height-pad)-((it-min)/span)*(height-2*pad);canvas.drawText("R ₹${String.format("%.0f",it)}",width-100,y-4,paint)}}
    }
}
