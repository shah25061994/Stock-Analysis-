package com.jainam.craftsmate

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var analyzePanel: View
    private lateinit var scannerPanel: View
    private lateinit var portfolioPanel: View
    private lateinit var dashboardPanel: View
    private lateinit var backtestPanel: View
    private lateinit var scannerResult: TextView
    private lateinit var portfolioResult: TextView
    private lateinit var portfolioSymbol: EditText
    private lateinit var portfolioQty: EditText
    private lateinit var portfolioAvg: EditText
    private lateinit var aiResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        analyzePanel = findViewById(R.id.analyzePanel)
        scannerPanel = findViewById(R.id.scannerPanel)
        portfolioPanel = findViewById(R.id.portfolioPanel)
        dashboardPanel = findViewById(R.id.dashboardPanel)
        backtestPanel = findViewById(R.id.backtestPanel)
        scannerResult = findViewById(R.id.scannerResult)
        portfolioResult = findViewById(R.id.portfolioResult)
        portfolioSymbol = findViewById(R.id.portfolioSymbol)
        portfolioQty = findViewById(R.id.portfolioQty)
        portfolioAvg = findViewById(R.id.portfolioAvg)
        aiResult = findViewById(R.id.aiResult)

        findViewById<Button>(R.id.tabDashboard).setOnClickListener { showPanel(dashboardPanel) }
        findViewById<Button>(R.id.tabAnalyze).setOnClickListener { showPanel(analyzePanel) }
        findViewById<Button>(R.id.tabBacktest).setOnClickListener { showPanel(backtestPanel) }
        findViewById<Button>(R.id.tabScanner).setOnClickListener { showPanel(scannerPanel) }
        findViewById<Button>(R.id.tabPortfolio).setOnClickListener { showPanel(portfolioPanel) }

        setupDashboard()
        setupAnalyzer()
        setupScanner()
        setupBacktest()
        setupPortfolio()
    }

    private fun showPanel(v: View) {
        dashboardPanel.visibility = if (v === dashboardPanel) View.VISIBLE else View.GONE
        analyzePanel.visibility = if (v === analyzePanel) View.VISIBLE else View.GONE
        scannerPanel.visibility = if (v === scannerPanel) View.VISIBLE else View.GONE
        backtestPanel.visibility = if (v === backtestPanel) View.VISIBLE else View.GONE
        portfolioPanel.visibility = if (v === portfolioPanel) View.VISIBLE else View.GONE
    }


    private fun setupDashboard() {
        val out=findViewById<TextView>(R.id.dashboardText)
        findViewById<Button>(R.id.refreshDashboard).setOnClickListener {
            out.text="Loading market snapshot…"
            executor.execute {
                try {
                    val d=Yahoo.fetch("^NSEI","5d","1d"); val p=d.close.last(); val prev=d.close.dropLast(1).lastOrNull()?:p; val ch=(p/prev-1)*100
                    runOnUiThread { out.text="NIFTY 50  ₹${f(p)}  ${if(ch>=0)"+" else ""}${f(ch)}%\n\nMarket regime: ${if(ch>=0)"Positive / Risk-on" else "Cautious / Risk-off"}\n\nCraftsmate AI scans the selected universe for trend alignment, momentum, volume and breakout structure. Use Scanner for ranked setups." }
                } catch(e:Exception){ runOnUiThread { out.text="Market snapshot unavailable: ${e.message}" } }
            }
        }
        findViewById<Button>(R.id.refreshDashboard).performClick()
    }

    private fun setupBacktest() {
        val sym=findViewById<EditText>(R.id.backtestSymbol); val out=findViewById<TextView>(R.id.backtestResult)
        findViewById<Button>(R.id.runBacktest).setOnClickListener {
            var s=sym.text.toString().trim().uppercase(Locale.US); if(s.isBlank())return@setOnClickListener; if(!s.contains("."))s+=".NS"; out.text="Running backtest…"
            executor.execute {
                try { val d=Yahoo.fetch(s,"2y","1d"); val r=Backtester.run(d); runOnUiThread { out.text=r } }
                catch(e:Exception){runOnUiThread{out.text="Backtest error: ${e.message}"}}
            }
        }
    }

    private fun setupAnalyzer() {
        val ticker = findViewById<EditText>(R.id.ticker)
        val status = findViewById<TextView>(R.id.status)
        val result = findViewById<TextView>(R.id.result)
        val chart = findViewById<PriceChartView>(R.id.chart)
        findViewById<Button>(R.id.analyze).setOnClickListener {
            var symbol = ticker.text.toString().trim().uppercase(Locale.US)
            if (symbol.isBlank()) return@setOnClickListener
            if (!symbol.contains(".")) symbol += ".NS"
            status.text = "Loading $symbol…"
            result.text = ""
            executor.execute {
                try {
                    val data = Yahoo.fetch(symbol, "6mo", "1d")
                    val a = Analyzer.analyze(data)
                    runOnUiThread {
                        status.text = "Updated: ${data.lastDate} • $symbol"
                        result.text = a.report()
                        chart.setData(data.close, a.supports, a.resistances)
                    }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Error: ${e.message ?: "Unable to fetch data"}" }
                }
            }
        }
    }

    private fun setupScanner() {
        findViewById<Button>(R.id.aiScan).setOnClickListener { runAiScan() }
        findViewById<Button>(R.id.scanNse).setOnClickListener {
            scannerResult.text = "Scanning NSE liquid stocks…\nThis can take 10–30 seconds."
            executor.execute {
                val symbols = NseUniverse.symbols
                val results = Collections.synchronizedList(mutableListOf<ScanRow>())
                val pool = Executors.newFixedThreadPool(8)
                symbols.forEach { symbol ->
                    pool.execute {
                        try {
                            val d = Yahoo.fetch(symbol, "5d", "15m")
                            if (d.close.size >= 30) {
                                val a = Analyzer.analyze(d)
                                val change = if (d.close.size >= 2) (d.close.last() / d.close[d.close.size - 2] - 1) * 100 else 0.0
                                results.add(ScanRow(symbol.removeSuffix(".NS"), d.close.last(), change, a.rsi, a.volumeRatio, a.bias, a.score, a.entry, a.stop, a.t1))
                            }
                        } catch (_: Exception) { }
                    }
                }
                pool.shutdown()
                while (!pool.isTerminated) Thread.sleep(100)
                val sorted = results.sortedWith(compareByDescending<ScanRow> { it.score }.thenByDescending { it.change })
                runOnUiThread {
                    scannerResult.text = buildScannerReport(sorted)
                }
            }
        }
    }

    private fun runAiScan() {
        aiResult.text = "Running multi-factor AI scan…\nScanning price action, trend, RSI, MACD, volume and volatility."
        executor.execute {
            val results = Collections.synchronizedList(mutableListOf<AiRow>())
            val pool = Executors.newFixedThreadPool(8)
            NseUniverse.symbols.forEach { symbol ->
                pool.execute {
                    try {
                        val d = Yahoo.fetch(symbol, "5d", "15m")
                        if (d.close.size >= 40) {
                            val a = Analyzer.aiAnalyze(d)
                            results.add(AiRow(symbol.removeSuffix(".NS"), a.price, a.aiScore, a.signal, a.entry, a.stop, a.t1, a.reasons))
                        }
                    } catch (_: Exception) {}
                }
            }
            pool.shutdown(); while (!pool.isTerminated) Thread.sleep(100)
            val sorted = results.sortedByDescending { it.aiScore }
            runOnUiThread { aiResult.text = buildAiReport(sorted) }
        }
    }

    private fun buildAiReport(rows: List<AiRow>): String {
        if (rows.isEmpty()) return "No data returned. Try again later."
        val sb=StringBuilder("CRAFTSMATE AI MARKET SCANNER\n\n")
        sb.append("Model = trend + momentum + RSI + MACD + volume + volatility + price action.\n\n")
        rows.take(20).forEachIndexed { i,r ->
            sb.append("${i+1}. ${r.symbol} ₹${f(r.price)}  AI ${r.aiScore}/100  ${r.signal}\n")
            sb.append("   Entry ₹${f(r.entry)} | SL ₹${f(r.stop)} | T1 ₹${f(r.t1)}\n")
            sb.append("   ${r.reasons.joinToString(" • ")}\n\n")
        }
        sb.append("AI score is a research signal, not a guaranteed prediction. Backtest before live execution.")
        return sb.toString()
    }

    private fun buildScannerReport(rows: List<ScanRow>): String {
        if (rows.isEmpty()) return "No market data returned. Yahoo Finance may rate-limit requests; try again in a minute."
        val sb = StringBuilder()
        sb.append("LIVE NSE SCANNER\n")
        sb.append("Updated: ${SimpleDateFormat("dd-MM HH:mm:ss", Locale.US).format(Date())}\n")
        sb.append("\nTop setups (15-minute data)\n\n")
        rows.take(25).forEachIndexed { i, r ->
            sb.append("${i + 1}. ${r.symbol}  ₹${f(r.price)}  ${if (r.change >= 0) "+" else ""}${f(r.change)}%\n")
            sb.append("   RSI ${f(r.rsi)} | Vol ${f(r.volume)}x | ${r.bias} ${r.score}/100\n")
            sb.append("   Entry ₹${f(r.entry)} | SL ₹${f(r.stop)} | T1 ₹${f(r.t1)}\n\n")
        }
        sb.append("\nScanner uses market-data API quotes. Quotes can be delayed depending on the provider. Confirm on your broker before trading.")
        return sb.toString()
    }

    private fun setupPortfolio() {
        findViewById<Button>(R.id.portfolioAnalyze).setOnClickListener {
            var symbol = portfolioSymbol.text.toString().trim().uppercase(Locale.US)
            if (symbol.isBlank()) return@setOnClickListener
            if (!symbol.contains(".")) symbol += ".NS"
            val qty = portfolioQty.text.toString().toDoubleOrNull() ?: return@setOnClickListener
            val avg = portfolioAvg.text.toString().toDoubleOrNull() ?: return@setOnClickListener
            portfolioResult.text = "Loading $symbol…"
            executor.execute {
                try {
                    val d = Yahoo.fetch(symbol, "5d", "1d")
                    val price = d.close.last()
                    val pnl = (price - avg) * qty
                    val pct = if (avg != 0.0) (price / avg - 1) * 100 else 0.0
                    val a = Analyzer.analyze(d)
                    val text = "${symbol.removeSuffix(".NS")}\nCurrent: ₹${f(price)}\nQuantity: ${f(qty)}\nAverage: ₹${f(avg)}\n\nP&L: ₹${f(pnl)} (${f(pct)}%)\n\nModel bias: ${a.bias} ${a.score}/100\nSupport: ${a.supports.joinToString(", ") { "₹${f(it)}" }}\nResistance: ${a.resistances.joinToString(", ") { "₹${f(it)}" }}"
                    runOnUiThread { portfolioResult.text = text }
                } catch (e: Exception) { runOnUiThread { portfolioResult.text = "Error: ${e.message}" } }
            }
        }
    }

    private fun f(x: Double) = String.format(Locale.US, "%.2f", x)
}

data class AiRow(val symbol:String,val price:Double,val aiScore:Int,val signal:String,val entry:Double,val stop:Double,val t1:Double,val reasons:List<String>)
data class ScanRow(val symbol:String,val price:Double,val change:Double,val rsi:Double,val volume:Double,val bias:String,val score:Int,val entry:Double,val stop:Double,val t1:Double)
data class MarketData(val dates: List<String>, val close: List<Double>, val high: List<Double>, val low: List<Double>, val volume: List<Long>) { val lastDate get() = dates.lastOrNull() ?: "" }

object Yahoo {
    fun fetch(symbol: String, range: String, interval: String): MarketData {
        val u = URL("https://query1.finance.yahoo.com/v8/finance/chart/${java.net.URLEncoder.encode(symbol, "UTF-8")}?range=$range&interval=$interval&events=history&includePrePost=false")
        val text = u.openConnection().apply { connectTimeout=10000; readTimeout=15000; setRequestProperty("User-Agent","Mozilla/5.0") }.getInputStream().bufferedReader().use { it.readText() }
        val result = JSONObject(text).getJSONObject("chart").getJSONArray("result").optJSONObject(0) ?: throw Exception("No data for $symbol")
        val ts=result.getJSONArray("timestamp"); val q=result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val c=q.getJSONArray("close"); val h=q.getJSONArray("high"); val l=q.getJSONArray("low"); val v=q.getJSONArray("volume")
        val d=mutableListOf<String>(); val cc=mutableListOf<Double>(); val hh=mutableListOf<Double>(); val ll=mutableListOf<Double>(); val vv=mutableListOf<Long>()
        val fmt = if (interval.endsWith("m")) SimpleDateFormat("dd-MM HH:mm", Locale.US) else SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for(i in 0 until ts.length()) if(!c.isNull(i)&&!h.isNull(i)&&!l.isNull(i)){ d.add(fmt.format(Date(ts.getLong(i)*1000))); cc.add(c.getDouble(i)); hh.add(h.getDouble(i)); ll.add(l.getDouble(i)); vv.add(if(v.isNull(i))0 else v.getLong(i)) }
        return MarketData(d,cc,hh,ll,vv)
    }
}

data class Analysis(val price:Double,val rsi:Double,val ema20:Double,val ema50:Double,val ema200:Double,val macd:Double,val signal:Double,val atr:Double,val supports:List<Double>,val resistances:List<Double>,val entry:Double,val stop:Double,val t1:Double,val t2:Double,val volumeRatio:Double,val score:Int,val bias:String){
    fun report() = """PRICE: ₹${f(price)}

TECHNICAL
RSI(14): ${f(rsi)}   |  MACD: ${f(macd)} / Signal ${f(signal)}
EMA 20: ₹${f(ema20)}   EMA 50: ₹${f(ema50)}   EMA 200: ₹${f(ema200)}
ATR(14): ₹${f(atr)}   Volume: ${f(volumeRatio)}× 20D average

SUPPORT
${supports.joinToString("   ") { "₹${f(it)}" }}

RESISTANCE
${resistances.joinToString("   ") { "₹${f(it)}" }}

TRADE PLAN (model estimate)
Entry zone: ₹${f(entry)}
Stop-loss: ₹${f(stop)}
Target 1: ₹${f(t1)}   Target 2: ₹${f(t2)}

BIAS: $bias   |   Score: $score/100

Use the levels as a decision aid, not as a guaranteed buy/sell signal."""
    private fun f(x:Double)=String.format(Locale.US,"%.2f",x)
}

object Analyzer {
    fun analyze(d:MarketData):Analysis {
        val c=d.close; val p=c.last(); val r=rsi(c,minOf(14,c.size-1)); val e20=ema(c,minOf(20,c.size)); val e50=ema(c,minOf(50,c.size)); val e200=ema(c,minOf(200,c.size)); val (m,s)=macd(c); val atr=atr(d,minOf(14,maxOf(1,d.close.size-1))); val avgVol=d.volume.takeLast(minOf(20,d.volume.size)).average().let{if(it==0.0)1.0 else it}; val vol=d.volume.last()/avgVol
        val recentLow=d.low.takeLast(minOf(30,d.low.size)).minOrNull() ?: p; val recentHigh=d.high.takeLast(minOf(30,d.high.size)).maxOrNull() ?: p
        val supports=listOf(recentLow, max(recentLow,p-atr), e20).distinct().sorted().take(3)
        val resist=listOf(recentHigh,p+atr,p+2*atr).distinct().sorted().take(3)
        val entry=min(p,e20); val stop=max(0.01,entry-1.2*atr); val t1=entry+1.5*atr; val t2=entry+2.5*atr
        var score=50; if(p>e20)score+=8; if(e20>e50)score+=8; if(e50>e200)score+=8; if(r in 45.0..65.0)score+=8 else if(r<35)score+=3; if(m>s)score+=10; if(vol>1.2)score+=3
        score=score.coerceIn(0,100); val bias=when{score>=70->"Bullish";score>=55->"Mild Bullish";score<=35->"Bearish";else->"Neutral"}
        return Analysis(p,r,e20,e50,e200,m,s,atr,supports,resist,entry,stop,t1,t2,vol,score,bias)
    }
    fun aiAnalyze(d:MarketData): AiResult {
        val c=d.close; val p=c.last(); val e20=ema(c,20); val e50=ema(c,50); val e200=ema(c,200); val r=rsi(c,14); val (m,s)=macd(c); val at=atr(d,14); val avg=d.volume.takeLast(minOf(20,d.volume.size)).average().coerceAtLeast(1.0); val vr=d.volume.last()/avg
        val hh=d.high.takeLast(40).maxOrNull() ?: p; val ll=d.low.takeLast(40).minOrNull() ?: p
        var score=50; val reasons=mutableListOf<String>()
        if(p>e20){score+=7;reasons+="above EMA20"}else{score-=6;reasons+="below EMA20"}
        if(e20>e50){score+=8;reasons+="EMA20>EMA50"}else{score-=7}
        if(e50>e200){score+=7;reasons+="long trend positive"}else{score-=6}
        if(m>s){score+=8;reasons+="MACD bullish"}else{score-=7}
        if(r in 45.0..68.0){score+=6;reasons+="RSI healthy"}else if(r>72){score-=5;reasons+="RSI hot"}else if(r<30){score+=2;reasons+="RSI oversold"}
        if(vr>1.5){score+=7;reasons+="volume spike"}else if(vr>1.1){score+=3;reasons+="volume improving"}
        val nearBreakout=p>=hh*0.995
        if(nearBreakout){score+=6;reasons+="near 40-bar high"}
        score=score.coerceIn(0,100)
        val signal=when{score>=78->"STRONG BUY SETUP";score>=68->"BUY WATCH";score<=35->"AVOID/BEARISH";else->"WAIT"}
        val entry=if(p>e20) min(p,e20*1.002) else p*0.995
        val stop=max(ll,entry-1.2*at)
        val t1=entry+1.8*at
        return AiResult(p,score,signal,entry,stop,t1,reasons)
    }

    fun ema(x:List<Double>,n:Int):Double { val nn=minOf(n,x.size); var e=x.take(nn).average(); val k=2.0/(nn+1); for(i in nn until x.size)e=x[i]*k+e*(1-k); return e }
    fun rsi(x:List<Double>,n:Int):Double { if(x.size<=n)return 50.0; var g=0.0;var l=0.0; for(i in 1..n){val z=x[i]-x[i-1];if(z>=0)g+=z else l-=z}; var ag=g/n;var al=l/n; for(i in n+1 until x.size){val z=x[i]-x[i-1];ag=(ag*(n-1)+max(z,0.0))/n;al=(al*(n-1)+max(-z,0.0))/n}; return if(al==0.0)100.0 else 100-100/(1+ag/al)}
    fun macd(x:List<Double>):Pair<Double,Double>{ if(x.size<30)return Pair(0.0,0.0); val arr=mutableListOf<Double>(); var e12=x.take(12).average();var e26=x.take(26).average();for(i in 26 until x.size){e12=e12*11/12+x[i]/6;e26=e26*25/26+x[i]/13;arr.add(e12-e26)}; val sig=if(arr.size<9)arr.last() else ema(arr,9);return Pair(arr.last(),sig)}
    fun atr(d:MarketData,n:Int):Double{if(d.close.size<2)return 0.0;val tr=mutableListOf<Double>();for(i in 1 until d.close.size)tr.add(max(d.high[i]-d.low[i],max(abs(d.high[i]-d.close[i-1]),abs(d.low[i]-d.close[i-1]))));return tr.takeLast(minOf(n,tr.size)).average()}
}

data class AiResult(val price:Double,val aiScore:Int,val signal:String,val entry:Double,val stop:Double,val t1:Double,val reasons:List<String>)

object NseUniverse {
    val symbols = listOf(
        "RELIANCE.NS","HDFCBANK.NS","ICICIBANK.NS","BHARTIARTL.NS","INFY.NS","TCS.NS","LT.NS","ITC.NS","SBIN.NS","AXISBANK.NS",
        "KOTAKBANK.NS","M&M.NS","HINDUNILVR.NS","BAJFINANCE.NS","MARUTI.NS","SUNPHARMA.NS","TITAN.NS","NTPC.NS","ADANIENT.NS","ADANIPORTS.NS",
        "ONGC.NS","POWERGRID.NS","TATASTEEL.NS","JSWSTEEL.NS","HCLTECH.NS","WIPRO.NS","TECHM.NS","ULTRACEMCO.NS","ASIANPAINT.NS","NESTLEIND.NS",
        "COALINDIA.NS","TATAMOTORS.NS","EICHERMOT.NS","TRENT.NS","BEL.NS","HAL.NS","SIEMENS.NS","ABB.NS","DLF.NS","PIDILITIND.NS",
        "INDUSINDBK.NS","BAJAJFINSV.NS","SBILIFE.NS","HDFCLIFE.NS","CIPLA.NS","DRREDDY.NS","APOLLOHOSP.NS","DIVISLAB.NS","TATAELXSI.NS","CRAFTSMAN.NS"
    )
}


object Backtester {
    fun run(d:MarketData):String {
        if(d.close.size<120)return "Not enough historical data."
        var cash=100000.0; var shares=0.0; var entry=0.0; var peak=cash; var maxDd=0.0; var wins=0; var trades=0
        for(i in 60 until d.close.size){
            val hist=MarketData(d.dates.take(i+1),d.close.take(i+1),d.high.take(i+1),d.low.take(i+1),d.volume.take(i+1)); val a=Analyzer.analyze(hist); val p=d.close[i]
            if(shares==0.0 && a.score>=68 && a.rsi<70){ shares=floor(cash/p); if(shares>0){cash-=shares*p; entry=p; trades++} }
            else if(shares>0 && (a.score<45 || p<entry-1.5*a.atr)){ val pnl=(p-entry)*shares; if(pnl>0)wins++; cash+=shares*p; shares=0.0 }
            val equity=cash+shares*p; peak=max(peak,equity); maxDd=max(maxDd,(peak-equity)/peak*100)
        }
        val last=d.close.last(); val equity=cash+shares*last; val ret=(equity/100000-1)*100; val wr=if(trades==0)0.0 else wins.toDouble()/trades*100
        return "INITIAL CAPITAL: ₹100,000\nFINAL EQUITY: ₹${String.format(Locale.US,"%.2f",equity)}\nRETURN: ${String.format(Locale.US,"%.2f",ret)}%\nTRADES: $trades\nWIN RATE: ${String.format(Locale.US,"%.1f",wr)}%\nMAX DRAWDOWN: ${String.format(Locale.US,"%.2f",maxDd)}%\n\nThis is a historical simulation, not a guarantee of future results. Brokerage/slippage/taxes are not included yet."
    }
}

interface BrokerAdapter { fun connect():Boolean; fun ltp(symbol:String):Double; fun placePaperOrder(symbol:String,side:String,qty:Int,price:Double):Boolean }
object BrokerConfig { const val PROVIDER="BROKER_API_ADAPTER"; const val NOTE="Connect a licensed broker/data API (e.g. Kite Connect) using user-supplied credentials; never hard-code API secrets." }
