package com.jainam.craftsmate.engine

import kotlin.math.*

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Long)
data class TimeframeSnapshot(val timeframe: String, val trendScore: Double, val momentumScore: Double, val volumeScore: Double, val rsi: Double)
data class TradePlan(val entryLow: Double, val entryHigh: Double, val stop: Double, val target1: Double, val target2: Double, val rr1: Double, val rr2: Double)
data class SignalDecision(val score: Int, val label: String, val confidence: Int, val plan: TradePlan, val reasons: List<String>, val risks: List<String>)

/**
 * Explainable, rule-based engine designed to be backtested.
 * It deliberately does not claim to predict prices or guarantee returns.
 */
object ProTradingEngine {
    fun decide(c: List<Candle>): SignalDecision {
        require(c.size >= 80) { "At least 80 candles required" }
        val close = c.map { it.close }
        val ema20 = ema(close, 20); val ema50 = ema(close, 50); val ema200 = ema(close, 200)
        val rsi = rsi(close, 14); val atr = atr(c, 14); val macd = macd(close)
        val avgVol = c.takeLast(20).map { it.volume }.average().coerceAtLeast(1.0)
        val relVol = c.last().volume / avgVol
        val high20 = c.takeLast(20).maxOf { it.high }; val low20 = c.takeLast(20).minOf { it.low }
        var score = 50; val reasons = mutableListOf<String>(); val risks = mutableListOf<String>()
        if (close.last() > ema20) { score += 8; reasons += "Price above EMA20" } else { score -= 7; risks += "Price below EMA20" }
        if (ema20 > ema50) { score += 8; reasons += "EMA20 above EMA50" } else { score -= 8; risks += "EMA20 below EMA50" }
        if (ema50 > ema200) { score += 8; reasons += "Long-term trend positive" } else { score -= 8; risks += "Long-term trend weak" }
        if (macd.first > macd.second) { score += 8; reasons += "MACD bullish" } else { score -= 6; risks += "MACD bearish" }
        when { rsi in 45.0..68.0 -> { score += 6; reasons += "RSI in healthy momentum zone" }; rsi > 72 -> { score -= 5; risks += "RSI overheated" }; rsi < 30 -> { score += 2; reasons += "RSI oversold; reversal possible" } }
        if (relVol >= 1.5) { score += 7; reasons += "Volume spike" } else if (relVol >= 1.15) { score += 3; reasons += "Volume improving" } else risks += "No volume confirmation"
        if (close.last() >= high20 * .995) { score += 6; reasons += "Near 20-bar breakout" }
        if (close.last() <= low20 * 1.01) risks += "Near 20-bar low"
        score = score.coerceIn(0, 100)
        val label = when { score >= 80 -> "STRONG SETUP"; score >= 68 -> "BUY WATCH"; score <= 35 -> "BEARISH"; else -> "WAIT" }
        val entryLow = min(close.last(), ema20)
        val entryHigh = max(close.last(), ema20) * 1.002
        val stop = max(low20, entryLow - 1.25 * atr)
        val risk = (entryHigh - stop).coerceAtLeast(0.01)
        val t1 = entryHigh + 1.8 * risk; val t2 = entryHigh + 2.8 * risk
        val rr1 = (t1 - entryHigh) / risk; val rr2 = (t2 - entryHigh) / risk
        val confidence = (50 + abs(score - 50) * 1.5 + if (relVol > 1.3) 8 else 0).roundToInt().coerceIn(0, 99)
        return SignalDecision(score, label, confidence, TradePlan(entryLow, entryHigh, stop, t1, t2, rr1, rr2), reasons, risks)
    }
    fun ema(x: List<Double>, n: Int): Double { val k=2.0/(n+1); var e=x.take(min(n,x.size)).average(); for(i in min(n,x.size) until x.size) e=x[i]*k+e*(1-k); return e }
    fun rsi(x: List<Double>, n:Int):Double { if(x.size<=n)return 50.0; var g=0.0;var l=0.0;for(i in 1..n){val z=x[i]-x[i-1];if(z>=0)g+=z else l-=z};var ag=g/n;var al=l/n;for(i in n+1 until x.size){val z=x[i]-x[i-1];ag=(ag*(n-1)+max(z,0.0))/n;al=(al*(n-1)+max(-z,0.0))/n};return if(al==0.0)100.0 else 100-100/(1+ag/al)}
    fun atr(c:List<Candle>, n:Int):Double { val tr=c.drop(1).mapIndexed{idx,x->val prev=c[idx].close;max(x.high-x.low,max(abs(x.high-prev),abs(x.low-prev)))};return tr.takeLast(min(n,tr.size)).average() }
    fun macd(x:List<Double>):Pair<Double,Double>{val e12=ema(x,12);val e26=ema(x,26);val m=e12-e26;return Pair(m,m*.85)}
}
