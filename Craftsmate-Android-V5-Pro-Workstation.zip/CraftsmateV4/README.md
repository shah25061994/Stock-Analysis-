# Craftsmate V5 — AI Trading Workstation for Android

A research-first Android app architecture for Indian markets. It combines live-data adapters, explainable multi-factor technical scoring, multi-timeframe analysis, scanners, risk-based trade plans, paper trading, portfolio tracking, alerts and backtesting.

## Product principles
- No guaranteed predictions or "accuracy" claims.
- Signals are explainable and backtestable.
- Separate market-data, analysis, UI and broker-execution layers.
- Broker credentials are never hard-coded.
- Paper trading is the default for new strategies.

## Core modules
1. Market dashboard — NIFTY regime, breadth hooks, volatility hooks.
2. NSE scanner — breakout, momentum, volume expansion, trend alignment, RSI/MACD filters.
3. AI-style score — 0–100 explainable score using trend, momentum, volume, volatility and price structure.
4. Multi-timeframe confirmation — 5m/15m/1h/1D architecture.
5. Trade planner — entry range, stop, T1/T2, risk-reward and invalidation.
6. Backtesting — historical simulation; production version should add walk-forward and out-of-sample validation.
7. Paper trading — log signals and measure real-time hit rate before enabling execution.
8. Portfolio — average cost, P&L, technical state and risk exposure.
9. Alerts — price, breakout, volume spike, RSI and strategy events.
10. Broker adapter — designed for licensed APIs such as Zerodha Kite Connect; user supplies credentials.

## Live NSE data
Yahoo Finance is used only as a development/demo source in this starter project. For production-grade live NSE data, connect a licensed broker/data provider. Kite Connect supports realtime WebSocket streaming and historical candle data. See https://zerodha.com/products/api/.

## Recommended production architecture
Android UI -> backend API -> market-data WebSocket -> normalized candle store -> indicator engine -> strategy engine -> risk engine -> alert service -> broker adapter.

For 500+ symbols, do not open one public HTTP request per symbol from the Android device. Use a backend streaming fan-out/cache, rate limiting, reconnect logic and market-session handling.

## Build
Open the `CraftsmateV4` directory in Android Studio. This repository is a feature-rich prototype; add a Gradle wrapper and production backend before distribution.
